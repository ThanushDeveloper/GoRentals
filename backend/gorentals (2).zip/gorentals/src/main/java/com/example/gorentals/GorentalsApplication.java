package com.example.gorentals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GorentalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GorentalsApplication.class, args);
	}

}
